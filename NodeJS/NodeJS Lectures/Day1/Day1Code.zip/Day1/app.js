let a = 1;
let b = 2;
let sum = a+b;

console.log("sum of a and b ="+sum);